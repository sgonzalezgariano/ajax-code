# ajax-code

This is the code for ajax exercises from The Web Developer Bootcamp
